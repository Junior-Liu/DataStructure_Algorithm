//import edu.princeton.cs.algs4.StdIn;
//import edu.princeton.cs.algs4.StdOut;
//import edu.princeton.cs.algs4.StdRandom;

public class HelloGoodbye {
    public static void main(String[] args){
        //while (StdIn.isEmpty()) {
        //    StdIn.readString();
        //    StdIn.readString();
        //};
        //if(args.length<2){
        //    StdOut.println("Usage: java HelloGoodbye <name1> <name2>");
        //    return;
        //}
        //String name1=args[0];
        //String name2=args[1];
        System.out.println("Hello "+args[0]+" and "+args[1]+".");
        System.out.println("Goodbye "+args[1]+" and "+args[0]+".");
    }
}


